#----------------------#
input=$1
output=$2
#----------------------#

echo "========================================"
echo "### plot Gmap ### "
echo "input:"  $input
echo "output:" $output
echo "========================================"
DIR="./Gmap/"
list=$DIR"countries.list"
ncon=`wc $list | awk '{print $1}'`
#echo $ncon
dim=`cat $input | awk '{if(NR==1) print NF}'`
#echo "dim:" $dim
for (( i=1; i<=$dim; i++ ))
do
#echo $i
infn="tmp.seq"
awk '{print $('$i')}' $input > $infn

outfn=$output"_"$i

#--- skip null patterns ----------#
isNULL=`sh $DIR"_isNULL.sh" $infn`
if [ $isNULL = 1 ]; then
outfn="trash"
fi
#---------------------------------#

cat $DIR"partA" > $outfn
awk '
{
  if(FNR==NR)
    state[FNR]=$1;
  else
    val[FNR]=$0
}
END{
for(i=1;i<='$ncon';i++){
    value=val[i]*100;  # value=log( (val[i])*100 +1)*10)
    #if(value>100) value=100;
    #continue;
    if(value>200) value=200;
    #if(value<50 || value>100)
    printf("[\"%s\", %d], \n", state[i], value)
}//i
}
' $list $infn >> $outfn
cat $DIR"partB" >> $outfn
#echo "save: " $outfn
done

# clean tmp files
rm $infn
rm "trash"

