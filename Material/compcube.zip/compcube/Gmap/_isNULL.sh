#-----------#
input=$1
#-----------#
# if vector (input) is uniform, 
# uniform : return 1
# else    : return 0
awk '
BEGIN{ isNULL=1; sum=0; delta=0.1; }
{ val[NR]=$1; sum+=$1; line=NR;}
END{
  avg=sum/line;
  for(i=1;i<line;i++){
    diff=val[i]-avg; diff=diff*diff;
    if(diff>delta)
        isNULL=0;
  }#i
  print isNULL
}' $input

