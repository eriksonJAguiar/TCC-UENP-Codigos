#!/bin/python
##############################################################
#    Yasuko Matsubara 
#    Date: 11-28-2014
##############################################################
import pylab
import numpy as np
import matplotlib.pyplot as plt
import math
from scipy.stats import norm
try:
    from sklearn.decomposition import FastICA, PCA
except:
    tool.error("can not find sklearn - please see http://scikit-learn.org")
import tool
import compress 
ZERO=1.e-100 
INF=1.e+100
#nb=256
#cF=8 #log2(nb)
BP=2 # bucets: (#BP, BP^2, BP^3, ...) 
DBG=0 #0
MAXITER=1000 #200
# Generate sample data
SPARSE_P=0.05
List=[221,39, 80,73,219,104,190, 173, 212, 179, 218, 13,150, 136,10,30, 45,98,183,106,112, 153,188,63]
List=map(int,List-np.ones(np.shape(List)))


def genDemo():
    np.random.seed(0)
    n_samples = 2000
    time = np.linspace(0, 8, n_samples)
    # signals
    s1 = np.sin(2 * time)  
    s2 = np.sign(np.sin(3 * time))  
    s3 = np.sin(10 * time)
    S = np.c_[s1, s2, s3]
    S += 0.2 * np.random.normal(size=S.shape)  # Add noise
    S /= S.std(axis=0)  # Standardize data
    # Mix data
    #A = np.array([[1, 1, 1], [0.5, 2, 1.0], [1.5, 1.0, 2.0]])  # Mixing matrix
    A = np.array([[1, 1, 1], [0, 1, 1], [1, 0, 1], [0.5, 2, 1.0], [1.5, 1.0, 2.0]])  # Mixing matrix
    X = np.dot(S, A.T)  # Generate observations
    return X
   
#-----------------------------#
#
# basic tools (ICA)  
# 
#-----------------------------#
def ica(X,k):
    try:
        ica = FastICA(n_components=k,max_iter=MAXITER)
        S_ = ica.fit_transform(X)  # Reconstruct signals S_[Pp][k]
        A_ = ica.mixing_  # Get estimated mixing matrix  A_[d][k]
        M_ = ica.mean_    # Mean values
    except:
        tool.warning('ICA fitting error: return k=0 components ...')
        (m,n) = np.shape(X)
        S_=np.zeros((m,k)); A_=np.zeros((n,k)); M_=0 
    if(False):
        X_=np.dot(S_, A_.T) + M_ 
        print np.allclose(X, X_)
    return (S_, A_, M_)

def positive(S_,A_,M_):
    (n,k)=np.shape(A_)
    for i in range(0,k):
        maxA=A_[np.argmax(abs(A_[:,i])),i]
        maxS=S_[np.argmax(abs(S_[:,i])),i]
        if(maxA<0):
        #if(np.sum(A_[:,i])<0):
        #if(maxS<0):
            S_[:,i]*=-1.0; A_[:,i]*=-1.0;
    return (S_, A_,M_)

def reconstruct(S_,A_,M_):
    X_=np.dot(S_, A_.T) + M_
    return X_

# Compute PCA
def pca(X,k):
    # For comparison, compute PCA
    pca = PCA(n_components=k)
    H = pca.fit_transform(X)  # Reconstruct signals based on orthogonal components
    return H


#-----------------------------#
#
# compress (ICA)  
# 
#-----------------------------#
# find optimal k with ICA
def ica_optk(X, mink, maxk):
    (Pp,nl)=np.shape(X);
    print("X: Pp:%d, nl:%d"%(Pp, nl))
    if(maxk<=1 or mink==maxk): 
        (S_,A_,M_)=ica(X,maxk); return (maxk,S_,A_,M_)
    # -------------------------------------------# 
    Cprev=INF; S_p=[];A_p=[];M_p=[]; optk=1;
    # (a) try each k
    klist=range(mink,maxk+1);
    #klist.extend(klist); klist.extend(klist);
    for k in klist: 
        # ICA - k components 
        (S_, A_, M_) = ica(X,k)
        # digitize/compress params
        (S_,A_,M_, nb) = _bucketize_opt(X,S_,A_,M_);
        ###(S_,A_,th)     = _sparse_opt(X,S_,A_,M_,nb);
        ###nb=64*2; 
        ###(S_,A_,M_)=_bucketize(S_, A_, M_, nb)

        per=SPARSE_P; # percentage  
        th=int(compress.count(X)/Pp*per)*k
        #print th
        (A_)=_sparse(A_, th)
        (C, cc,cm)=_costT(X, S_,A_,M_, nb)
        nS=compress.count(S_); nA=compress.count(A_) 
        print('ica_k: k: %d (nb:%d,th:%d)[nS:%d,nA:%d], cost:%.0f (cc:%.0f, cm:%.0f)'%(k, nb,th, nS,nA, C, cc, cm))
        #print("%d %.0f %.0f %.0f %d "%(k, C, cc, cm, nb))
        #if(Cprev<C): break;
        #Cprev=C; S_p=S_; A_p=A_; M_p=A_; optk=k;
        if(Cprev<C): continue;
        else: Cprev=C; S_p=S_; A_p=A_; M_p=A_; optk=k; optnb=nb; optth=th;
    # (b) compute optimal param set
    (S_, A_, M_) = ica(X,optk)
    (S_,A_,M_)=_bucketize(S_, A_, M_, optnb)
    (A_)=_sparse(A_, optth)
    print('ica_opt: k: %d (nb:%d), cost:%.0f'%(optk, optnb, Cprev))
    # -------------------------------------------# 
    return (optk, S_p, A_p, M_p, optnb)

def _costT(X_org,S_,A_,M_, nb):
    (Pp,k)=np.shape(S_) # Pp: sequence length,  / #k: # of components
    (d,k) =np.shape(A_) # d: # of data samples, / #k: # of components
    X_ = reconstruct(S_,A_,M_)
    costC = compress.coding(X_,X_org) # diff, X_reconst vs. X_org
    #CostM = tool.log_s(k) + tool.log_s(d) + tool.log_s(Pp);
    # #of nonzero variables
    nS=compress.count(S_) 
    nA=compress.count(A_) 
    #print("S_,%d, A_,%d"%(nS, nA))
    #CostM += tool.log2(nb)*(nS + nA)
    #CostM += (nS)*(tool.log2(k)+tool.log2(Pp)+tool.log2(nb))
    #CostM += (nA)*(tool.log2(d)+tool.log2(k) +tool.log2(nb))
    costM = compress.CostM_season(nS, nA, k, d, 1, Pp, tool.log2(nb))
    costT  = costC + costM
    if(math.isnan(costT)): costT=INF;
    if(DBG):print "k:%d, nb:%d, costM:%.0f, costC:%.0f, costT:%.0f"%(k, (nb), costM, costC, costT)
    return (costT, costC, costM)

def _sparse(Aorg, top_nA):
    As=Aorg.copy(); (d,k)=np.shape(Aorg);
    Ath=sorted(abs(As.flatten()), reverse=True)[top_nA-1] 
    As[abs(As)<Ath]=0;
    #print compress.count(As)
    return As;

'''
def _sparse_opt(X_org,  S_,A_,M_, nb):
    A_org=A_.copy(); 
    optth=0; Cprev=INF;
    for j in range(80,100,5):
        th=j*0.01; #*percentage
        A_=_sparse(A_org,th);
        #S_=_sparse(S_,th*0.5);
        (C,cc,cm)=_costT(X_org, S_,A_,M_, nb)
        if(Cprev<C): break;
        optth=th; Cprev=C; 
    A=_sparse(A_org,optth);
    return (S_, A_, optth);
'''

def _bucketize(S_, A_, M_, nb):
    S_b=compress.bucketize(S_,nb);
    A_b=compress.bucketize(A_,nb);
    M_b=compress.bucketize(M_,nb);
    return (S_b, A_b, M_b)
def _bucketize_opt(X_org, S_,A_,M_):
    optnb=1; Cprev=INF;
    for i in range(4,10): #2^4=16,32,64,...,...)
        nb=BP**i #BP, BP^2, BP^3 ...
        (S_b,A_b,M_b)=_bucketize(S_,A_,M_, nb)
        (C,cc,cm)=_costT(X_org, S_b,A_b,M_b, nb)
        if(Cprev<C): break;
        optnb=nb; Cprev=C;
    (S_b,A_b,M_b)=_bucketize(S_,A_,M_, optnb)
    return (S_b,A_b,M_b, optnb)


#----------------------------#
#  Plot results
#----------------------------#
def plotResults(X, S_,W, outdir):
    (Pp, optk)=np.shape(S_)
    (optk,d,l)=np.shape(W)
    # original
    plt.figure()
    plt.subplot(2,2,1)
    plt.plot(X)
    plt.xlim(-4,Pp+4)
    plt.title("original: %d x %d"%(np.shape(X)))
    # ICA components 
    plt.subplot(2,2,2)
    plt.plot(S_)
    plt.xlim(-4,Pp+4)
    plt.title("ICA comps (k=%d)"%(optk))
    # --- COMPs --- #
    for k in range(0,optk):
        plt.subplot(6,optk,-optk+6*optk-optk+1+k)
        plt.plot(S_[:,k])
        #plt.stem(S_[:,k],markerfmt=",")
        plt.xlim(-4,Pp+4)
        pylab.title("B (%d)"%(k+1))
        plt.axis('off')
    v=max(abs(W[:,:,List].flatten()))
    for k in range(0,optk):
        plt.subplot(6,optk,6*optk-optk+1+k)
        #v=max(abs(W[k,:,List].flatten()))
        plt.imshow(W[k,:,List].T, interpolation='nearest',aspect='auto', vmin=-v,vmax=v)
        plt.xticks(np.arange(0,len(List)), range(1,len(List)+1))
        plt.yticks(np.arange(0,d), range(1,d+1))
        pylab.title("W (%d)"%(k+1))
        plt.axis('off')
    plt.subplots_adjust(0.09, 0.04, 0.94, 0.94, 0.26, 0.46)
    plt.savefig(outdir+'result.pdf')
    plt.show(block=False)
    # --- COMPs --- #



#---------------#
#     main      #
#---------------#
if __name__ == "__main__":



    X = genDemo()
    X = pylab.loadtxt("../output/full/products/out_cs/Comp/season/Sf")
    #X = pylab.loadtxt("../output/full/beer/out/Comp_S/Sf")
    #X = pylab.loadtxt("../output/full/cocktails/out/Comp_S/Sf")

    #X = pylab.loadtxt("../output/full/news_sources/out/Comp_S/Sf")
    #X = pylab.loadtxt("../output/full/social_media_sites/out/Comp_S/Sf")
    #X = pylab.loadtxt("../output/full/financial_companies/out/Comp_S/Sf")
    #X = pylab.loadtxt("../output/full/car_companies/out/Comp_S/Sf")

    ''' 
    print np.shape(X)
    #-------------------------# 
    k=3 
    (S_, A_, M_) = ica(X,k)
    #-------------------------# 
    plt.figure()
    plt.plot(S_)  
    plt.show() 
    '''

    #optk=k
    (optk, S_, A_, M_,optnb) = ica_optk(X,1,50)
    (S_, A_, M_) = positive(S_,A_,M_)
    #-------------------------# 
    #H  = pca(X,k)
    #-------------------------# 

    (dl, k)= np.shape(A_)
    l=237; d=int(dl/l)
    print("dl:%d, l:%d, d:%d"%(dl, l, dl/l))
    W=np.zeros((optk,d,l)) #A_[:,0]
    for k in range(0,optk):
        for i in range(0,d):
            for j in range(0,l): 
                W[k][i][j]=A_[i*l+j][k]

    outdir='./dat/'
    np.savetxt(outdir+'S_cp_B', S_.T, fmt='%.3f', delimiter="\t")
    for k in range(0,optk):
        np.savetxt(outdir+'S_cp_W_%d'%(k+1), W[k], fmt='%.3f', delimiter="\t")
    plotResults(X, S_,W, outdir);


