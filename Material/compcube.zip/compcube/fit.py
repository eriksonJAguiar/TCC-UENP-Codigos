import pylab
import sys
import numpy as np
import matplotlib.pyplot as plt
import tool
import model 
import time
import ica
import os
import math
import compress 
try:
    from lmfit import Parameters, Minimizer
except:
    tool.error("can not find lmfit - please see http://lmfit.github.io/lmfit-py/")
# basic vals
INF=1.e+20 #100
ZERO=1.e-100 #4 #20 #20 #20 #1.e-100 
YES=1; NO=0;
# for lmfit 
MAXITER=50
DELTA=0.005 #0.5*1.e-2 #1.e-2
DELTAL=0.01 #1.e-2 # for local-fit
# debug, etc. 
DISPLAY=NO #NO #(YES/NO)
COMMENT=NO #NO#(YES/NO)
LOCAL=NO
# for TETRAfit()
KMAX=1000
SEED=1
RANDS=NO #YES #NO # random seed (YES/NO)
# for extra fitting
MAXEXTRA=100

#----------------------------#
#    model fitting (global)  #
#----------------------------#
def Gfit(model, outdir, wantDisp):
    global KMAX; KMAX=max(model.data.flatten())*1.0+ZERO; 
    # set seed (optional)
    if(RANDS): global SEED; SEED=np.random.seed(os.getpid());
    if(wantDisp): global DISPLAY; DISPLAY=YES;
    tool.comment("start Global fitting") 
    #---setting ---------------------#
    tic = time.clock()
    model=_Gfit(model)
    toc = time.clock(); fittime= toc-tic;
    #--------------------------------#
    #--- show results and save data ---#
    tool.comment("end Global fitting")
    print("time: %f"%fittime)
    print("rmse: %f"%model.dist('lin'))
    print("cost: %f"%model.cost())
    if(outdir!=''):
        model.saveModel(outdir)
    #--------------------------------#
    return model
#----------------------------#
#    model fitting (local)   #
#----------------------------#
def Lfit_each(modelL, outdir, wantDisp):
    global KMAX; KMAX=max(modelL.data.flatten())*1.0+ZERO; 
    # set seed (optional)
    if(RANDS): global SEED; SEED=np.random.seed(os.getpid());
    if(wantDisp): global DISPLAY; DISPLAY=YES;
    tool.comment("start Local fitting") 
    #---setting ---------------------#
    tic = time.clock()
    modelL=_LocalFit(modelL)
    toc = time.clock(); fittime= toc-tic;
    #--------------------------------#
    #--- show results and save data ---#
    tool.comment("end Local fitting")
    print("time: %f"%fittime)
    print("rmse: %f"%modelL.dist('lin'))
    print("cost: %f"%modelL.cost())
    if(outdir!=''):
        modelL.saveModel(outdir)
    #--------------------------------#
    return modelL

def Lfit(X, modelG, outdir, wantDisp, List):
    global LOCAL; LOCAL=YES;
    global DELTA; DELTA=DELTAL;
    modelL=[] # modelL[l]
    (d,l,n)=np.shape(X) # tensor X(d,l,n)
    print("Lfit: (%d,%d,%d)"%(d,l,n))
    # (a)--- alloc local modelL[l]
    for j in range(0,l):
        Xl=np.zeros((d,n))
        for i in range(0,d):
            Xl[i] = X[i][j]
        model_p=modelG.copyModel()
        model_p.data=Xl;
        modelL.append(model_p)
    # (b)--- local fit
    for j in List:
        outfn=outdir+"%d_"%(j+1)
        modelL[j] = Lfit_each(modelL[j], outfn, wantDisp);
    return modelL

#----------------------#
# TETRAfit 
#----------------------#
def _TETRAfit(model, wantInit, baseFit,seasonFit,extraFit):
    model.data[np.isnan(model.data)]=0;
    model_prev=[]; err_prev=INF;  
    model_best=model.copyModel(); 
    err_best=model.dist('lin'); 
    if(wantInit): _initParams(model)
    MAXITER_T = 4;
    for i in range(0,MAXITER_T):
        # (a) base fitting
        if(baseFit): model=_LMfit_base(model)
        # (b) seasonal fitting
        if(seasonFit): model=_LMfit_season(model);
        # (c) extra fitting
        if(extraFit): model=_LMfit_extra(model);
        # if diff < DELTA, stop iter
        err=model.dist('lin')
        #if(DISPLAY): model.saveModel('')
        if(COMMENT): print("TETRAfit: (err:%.2e)"%err)
        if(abs(err-err_prev)<DELTA): break;
        if(err < err_best): model_best=model.copyModel(); err_best=err; 
        err_prev=err; model_prev=model.copyModel();
    if(COMMENT): print("TETRAfit: (err:%.2e)"%err_best)
    if(COMMENT): model_best.printParams('')
    return model_best


def _copyBaseParamsIDX(mfrom, mto, idxf, idxt):
    if(len(idxf)!=len(idxt)): tool.error('# of idx from != to')
    for i in range(0,len(idxf)):
        mto.p[idxt[i]] = mfrom.p[idxf[i]]
        mto.K[idxt[i]] = mfrom.K[idxf[i]]
        mto.r[idxt[i]] = mfrom.r[idxf[i]]
        for j in range(0,len(idxf)):
            mto.A[idxt[i]][idxt[j]]=mfrom.A[idxf[i]][idxf[j]]
        mto.season.S[idxt[i]] = mfrom.season.S[idxf[i]]
        mto.season.W[idxt[i]][idxt[i]] = mfrom.season.W[idxf[i]][idxf[i]]
        for j in range(0,len(idxf)):
            mto.season.W[idxt[i]][idxt[j]]=mfrom.season.W[idxf[i]][idxf[j]]
        mto.extra.E[idxt[i]] = mfrom.extra.E[idxf[i]]

def _Gfit(modelG):
    d = modelG.d; 
    # reset A matrix (all zero)
    modelG.A=np.zeros((d,d))
    # === (I) solo-fitting === #
    tool.comment('(I) individual fitting')
    d_p=1; 
    for i in range(0,d):
        print("fit: seq[%d]"%(i))
        data_p=modelG.data[[i],:]
        model_p=model.GeoCompG(d_p,modelG.n,data_p)
        # if too small, then, ignore seasonality
        if(_isSparse(data_p,th=0.2)): model_p.S_V[0]=0;
        model_p=_TETRAfit(model_p, YES, YES,YES,YES)
        # assign params modelG <- model_p 
        _copyBaseParamsIDX(model_p, modelG, [0], [i])
    # === (II) pair-fitting === #
    tool.comment('(II) pair fitting')
    d_p=2; 
    V_bi=np.zeros(d);
    # +++ sample-fitting +++ #
    while(True):
        errG_prev=modelG.dist('lin')
        if(DISPLAY): modelG.saveModel('') 
        err_b=INF; model_b=[]; i_b=-1; j_b=-1; # best pair
        Dist=modelG.dist_each('lin')
        Dist[V_bi==1] = 0 # if already optimized, then, ignore
        # (a-1) choose most unfitted single seq i
        i=np.argmax(Dist) 
        if(COMMENT): print "choose single seq: %d (err:%.2e)"%(i,Dist[i])
        # (a-2) if fitting accuracy is good enough, stop fitting
        if(Dist[i] < DELTA): break
        # (b) pair fit with seq j
        for j in range(0,d):
            if(i==j): continue
            # (b-1) check other involving seqs ... data[jj]
            pairs=_SubsetC([i,j],modelG);
            data_p=modelG.data[pairs,:]; d_p=len(pairs)
            model_p=model.GeoCompG(d_p,modelG.n,data_p)
            _copyBaseParamsIDX(modelG, model_p, pairs, range(0,d_p))
            # (b-2) fitting only (i vs. j)
            model_p.initVary(0) # fixed params
            model_p.p_V[0]=1; model_p.r_V[0]=1; model_p.K_V[0]=1; 
            model_p.A_V[0][1]=1; 
            # (b-3) start fitting
            model_p=_TETRAfit(model_p, NO, YES,NO,YES)
            # check fitting error (err_p) for seq i (i.e. 0)
            errs=model_p.dist_each('lin'); err_p=errs[0]
            #err_p=model_p.dist('lin')
            if(err_b > err_p): # update best pair
                model_b=model_p; i_b=i; j_b=j; err_b=err_p; pairs_b=pairs; #err_diff;
        if(COMMENT): print "--best pair: (%d,%d), (err:%.2e)"%(i_b,j_b,err_b)
        # (c) if no candidate, then stop pair fitting
        if(i_b==-1 or j_b==-1): break;
        V_bi[i_b]=1; V_bi[j_b]=1;  # fix pair 
        # (d) update params (best pairs) 
        _copyBaseParamsIDX(model_b, modelG, range(0,model_b.d), pairs_b)
    # === (III) multi-fitting === #
    tool.comment('(III) full fitting')
    modelG.initVary(1) # fixed params
    modelG.saveModel('')
    modelG.season.resetSEASON();
    modelG.saveModel('')
    modelG=_TETRAfit(modelG, NO, NO,YES,YES)
    if(DISPLAY): modelG.saveModel('')
    return modelG

RINI=0.04; RMAX=0.1;
#--------------------------------------#
#    objective functions  #
#    return the array to be minimized
#--------------------------------------#
def _distfunc(params, model, outdir):
    d = model.d; data = model.data;
    for i in range(0,d):
        model.K[i]  = abs(params['K_%i'%i].value);
        model.p[i]  = abs(params['p_%i'%i].value);
        model.r[i]  = abs(params['r_%i'%i].value);
        for j in range(0,d):
            model.A[i][j] = abs(params['A_%i_%i'%(i,j)].value);
    # make model
    (X) = model.getModel();
    diff=data.flatten() - X.flatten()
    diff[np.isnan(diff)]=0
    return pow(diff, 2)

def _initParams(model):
    r = 0.001;
    if(RANDS): r=0.001*np.random.random()
    for i in range(0,model.d):
        if(model.K_V[i]): model.K[i]  = (max(model.data[i])+ZERO)*(1.0+r)
        #if(model.p_V[i]): model.p[i]  = (model.data[i][0]+ZERO)*(1.0+r)
        if(model.p_V[i]): model.p[i]  = (np.mean(model.data[i][0:4])+ZERO)*(1.0+r)
        if(model.r_V[i]): model.r[i]  = (RINI)*(1.0+r)
        for j in range(0,model.d):
            if(model.A_V[i][j]): model.A[i][j] = 0.1*(1.0+r)
        model.A[i][i] = 1.0

#---------------------------#
# base fitting (p, r, K, A)
#---------------------------#
def _LMfit_base(model):
    #--- (a) create a set of Parameters -----#
    params = Parameters()
    mxA=10; mxk=KMAX; mxr=RMAX 
    if(LOCAL): mxr=RMAX; # if local-fitting, then, do ...
    for i in range(0,model.d):
        params.add('r_%i'%i, value=model.r[i], min=-mxr,max=mxr,vary=model.r_V[i])
        params.add('p_%i'%i, value=model.p[i], min=-mxk,max=mxk,vary=model.p_V[i])
        params.add('d_%i'%i, value=model.K[i]-model.p[i], min=-mxk,max=mxk,vary=model.K_V[i])
        #params.add('K_%i'%i, value=model.K[i], min=-mxk,max=mxk,vary=model.K_V[i])
        params.add('K_%i'%i, expr='p_%i + d_%i'%(i,i))       # K[i]=p[i]+ d[i]  (d:delta)
        #params.add('K_%i'%i, expr='p_%i + abs(d_%i)'%(i,i)) # K[i]=p[i]+|d[i]| (d:delta)
        for j in range(0,model.d):
            params.add('A_%i_%i'%(i,j),value=model.A[i][j],min=-mxA,max=mxA,vary=model.A_V[i][j])
        params['A_%i_%i'%(i,i)].vary=False
    #--- (b) start fitting ------------------#
    lmsol = Minimizer(_distfunc, params, fcn_args=(model, ''))
    lmsol.leastsq(xtol=DELTA, ftol=DELTA, maxfev=MAXITER)
    return model


def _createEhat(model, X):
    d = model.d; n = model.n; data = model.data;
    Pp = model.season.Pp;     # Pp: period
    s = int(np.ceil((n/Pp))); #  s: #ofsubseqs 
    # (a-2) make E and Ehat 
    delta=1.0 # to avoid 1/0 fitting
    delta2=0.1; 
    if(LOCAL): delta2=0.001; # if localfit, then delta~0.
    E=(data.T-(X.T))/(X.T+delta)+delta2; E=E.T 
    E[np.isnan(E)]=0;
    # if global-fit, then normalize E i.e., N(0,1.0)
    if(LOCAL==NO):
        for i in range(0,d):
            E[i] = tool.normalizeZ(E[i])
    # --- compute Ehat --- #
    # (a-3) create avg matrix of size (d x Pp)
    Ehat=np.zeros((d,Pp)) # Ehat: subseq set (d x Pp)
    for i in range(0,d):
        for t in range(0,Pp*s): #range(0,n):
            loc=np.mod(t,Pp)
            Ehat[i][loc]+=E[i][t]
    Ehat /= s; # normalize
    # --- compute Ehat --- #
    return Ehat

def _distfunc_seasoni(params, model, X, i):
    model.season.W[i][i] = params['W'].value
    Yi = X[i] * (1 + model.season.getEidx(model.n, i))
    diff=model.data[i]-Yi
    diff[np.isnan(diff)]=0
    return pow(diff, 2)
#---------------------------#
# seasonal fitting (S)
#---------------------------#
def _LMfit_season(model):
    d = model.d; n = model.n; data = model.data;
    #--- (I) make seasonal components ---#
    # (a-1) X: model without season pattern
    X = model.getModel();
    # create E, Ehat
    Ehat=_createEhat(model, X)
    #--- (II) exo W witting ---#
    for i in range(0,d):
        if(model.S_V[i]==0): continue;
        model.season.S[i]=Ehat[i]
        model.season.W[i]=np.zeros((d))
        params = Parameters()
        params.add('W', value=1.0, min=0.1)
        #--- start fitting -----#
        lmsol = Minimizer(_distfunc_seasoni, params, fcn_args=(model, X, i))
        lmsol.leastsq(xtol=DELTA, ftol=DELTA, maxfev=MAXITER)
        model.season.S[i] *= params['W'].value
        # avoid over-fit 
        mx=max(abs(model.season.S[i]));
        if(mx>2.0): tool.warning("LMfit_season: re-size"); model.season.S[i]/=mx*2;
        model.season.W[i][i]=1.0;
    return model  
    
#---------------------------#
# extra fitting (E)
#---------------------------#
def _LMfit_extra(model):
    d = model.d; n = model.n; data = model.data;
    maxk=MAXEXTRA; 
    cF=model.extra.cF;
    #--- make extra components ---#
    # (a-1) X: model without extra pattern
    model.extra.resetEXTRA();
    X = model.getModel();
    # (a-2) make diff patterns ---#
    diff=(data.T-(X.T)).T
    # (a-3) find most unfitted points (0<=k<=maxk)
    model_prev=model.copyModel()
    cost_prev=INF; # nE > 0 
    for k in range(0,maxk):
        # ignore nan
        diff[np.isnan(diff)]=0
        # find most unfitted point (i,t)
        (i, t) = np.unravel_index(np.abs(diff).argmax(), diff.shape)
        if(model.E_V[i]==0): diff[i,t]=0; continue; 
        model.extra.addEXTRA(i,t,data[i,t])
        diff[i,t]=0; # reset point
        cost_curr=compress.coding(diff, diff*0)  # CostC
        cost_curr += compress.CostM_extra(k, d,1,n, cF); # CostM
        if(cost_curr>cost_prev): # and k>0):
            model=model_prev; break;
        else:
            cost_prev=cost_curr; model_prev=model.copyModel()
    if(COMMENT): print("optk(extra):%d"%model.extra.getOptK())
    return model



def _isNaN(model):
    d=model.d; n=model.n; data=model.data;
    print("_isNaN(): avg:%f"%(np.mean(data.flatten())))
    if(np.mean(data.flatten())==0):
        data[:]=np.nan;
        return True;
    else:
       return False;

def _SubsetC(seeds, model):
    d=model.d; 
    pairs=seeds; #pairs=[i];
    # (a-1) check other involving seqs ... data[jj]
    pairs_prev=[];
    while(len(pairs)!=len(pairs_prev)):
        for pi in pairs:
            for jj in range(0,d):
                if(model.A[pi][jj]>0):
                     if(pairs.count(jj)==0): pairs.append(jj);
        pairs_prev=pairs;
    print("subsetC:"); print(pairs);
    return pairs;

def _LocalFit(modelL):
    tool.comment("localfit")
    d = modelL.d; data=modelL.data
    modelL.extra.resetEXTRA();
    modelL.season.resetSEASON();
    # if all zero, return;
    if(_isSparse(data,th=0.1)): data[:]=np.nan; return modelL; 
    if(_isNaN(modelL)): return modelL; 
    tool.comment('(I) single fitting')
    for i in range(0,d):
        pairs=_SubsetC([i],modelL);
        if(len(pairs)>1): continue;
        data_p=data[pairs,:]; d_p=len(pairs)
        model_p=model.GeoCompG(d_p,modelL.n,data_p)
        _copyBaseParamsIDX(modelL, model_p, pairs, range(0,d_p))
        model_p.initVary(1);
        # reset params (r & p)
        model_p=_Vsparse(model_p);
        model_p=_TETRAfit(model_p, NO, YES,YES,YES)
        _copyBaseParamsIDX(model_p, modelL, range(0,d_p), pairs)
    tool.comment('(II) multiple fitting')
    for i in range(0,d):
        pairs=_SubsetC([i],modelL);
        if(len(pairs)==1): continue;
        data_p=data[pairs,:]; d_p=len(pairs)
        model_p=model.GeoCompG(d_p,modelL.n,data_p)
        _copyBaseParamsIDX(modelL, model_p, pairs, range(0,d_p))
        # (a-2) start fitting indiv fit & inter fit (i vs j) 
        model_p.initVary(0);
        model_p.p_V[0]=1; model_p.r_V[0]=1; model_p.K_V[0]=1; model_p.A_V[0,:]=1; model_p.S_V[0]=1;
        model_p.A_V=model_p.A>0
        model_p=_Vsparse(model_p);
        model_p=_TETRAfit(model_p, NO, YES,YES,YES)
        _copyBaseParamsIDX(model_p, modelL, range(0,d_p), pairs)
    #tool.comment('(III) full fitting (extra)')
    #modelL.initVary(1);
    #modelL=_TETRAfit(modelL, NO, NO,NO,YES)
    return modelL

# th+=e.g., 0.2 or 0.4
def _isSparse(data,th):
    dmin=KMAX*0.1;
    #(tmp,n)=np.shape(data)
    (n)=len(data.flatten())
    if(len(data[data>dmin])<n*th): 
        return True;
    else:  
        return False;

#----------------------------#
#    if data is sparse, then fix params
#----------------------------#
def _Vsparse(model):
    d=model.d; n=model.n; data=model.data;
    for i in range(0,d):
        di=data[i];
        if(len(di[di>0])<n*0.2): 
        #if(_issparse(di,0.2)):
            model.data[i,:]=np.nan;
            model.p[i]=0; model.p_V[i]=0; 
            model.r_V[i]=0; model.K_V[i]=0;
            model.A_V[i,:]=0; model.A_V[:,i]=0;
            model.S_V[i]=0; model.E_V[i]=1;
        # if too small, then, ignore
        if(len(di[di>0])<n*0.4):
            model.S_V[i]=0; model.E_V[i]=1; 
        if(_isSparse(di,0.4)):
            model.E_V[i]=1;
    return model 

 
