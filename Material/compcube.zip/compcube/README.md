======================================
[CompCube](http://www.cs.kumamoto-u.ac.jp/~yasuko/)
======================================

Author:    Yasuko Matsubara 

Created:   2016-05-16

------------
Introduction
------------

This is a python code of "CompCube"

------------
Quick demo
------------

	1. Interactive demo 
       		$ make demo
	2. Fitting data
       		$ make fit

------------
Installation
------------

python settings: You might need to install "lmfit" and "sklearn", 

	 - lmfit (for fit.py): 
		$ git clone git://github.com/lmfit/lmfit-py
		$ sudo python setup.py install
	 - sklearn (for fastica, ica.py):
	    $ git clone git://github.com/scikit-learn/scikit-learn
	    $ sudo python setup.py install


------------
Datasets
------------

See `./DATA/`
Please also see `compcube_data.zip` (full version)

------------
References
------------

Please see, 
Yasuko Matsubara, Yasushi Sakurai, Christos Faloutsos, 
"Non-Linear Mining of Competing Local Activities", WWW 2016.

------------
Updates
------------

Version: `5-16-2016`
    - released



