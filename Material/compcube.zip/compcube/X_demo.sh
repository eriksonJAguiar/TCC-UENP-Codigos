# demo - interactive compcube

#---------------------------#
label="products"
#label="news_sources"
#---------------------------#

model="OUT/"$label"/out/fitG/"
python main_interact.py $model

