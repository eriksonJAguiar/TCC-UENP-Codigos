#!/bin/python
##############################################################
#    Yasuko Matsubara 
#    Date: 09-30-2014
##############################################################
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import pylab
import sys
import argparse
import tool
import model
YES=1; NO=0;
WDSIZE=1
NORM=NO
MAXN=10000 
#------------------------#
#
#     main function   
#     e.g., python main_gen.py $model $mtype $outdir 
#
#------------------------#
if __name__ == "__main__":
    #--- arguments ---#
    parser = argparse.ArgumentParser()
    parser.add_argument("-m",  "--modelfn",type=str, help="input model filename")
    parser.add_argument("-t",  "--mtype",  type=str, help="model type [u/k]")
    parser.add_argument("-o",  "--outdir", type=str, help="output dir (optional)")
    parser.add_argument("-n",  "--n",      type=int, help="set duration n (optional)")
    args = parser.parse_args()
    #--- check sequencefn, mtype ---#
    if(args.modelfn!=None and args.mtype!=None):
        modelfn = args.modelfn
        mtype = args.mtype
    else: parser.print_help()
    #--- check output dir ---#
    if(args.outdir!=None): outdir = args.outdir
    else: outdir = '';
    #--- check n (duration) ---#
    if(args.n>1): my_n=args.n
    else: my_n=MAXN
    #--- print args ---#
    tool.comment('args')
    print "-------------------------"
    print "mtype:  [%s]"%mtype
    print "modelfn:[%s]"%modelfn
    print "outdir: [%s]"%outdir
    print "-------------------------"

    #--- create/load parameter set ---#
    model = model.GeoCompG(1,1,[])
    model.readParams(modelfn);
    if(my_n!=MAXN and model.n<my_n): model.n=my_n;
    #--- gen model ---#
    # if wantoutfn: save fig, else: plot fig) ---#
    if(outdir==''): wantBlock=True;
    else: wantBlock=False;         
    model.saveModel(outdir,wantBlock)



