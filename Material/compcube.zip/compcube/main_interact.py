#!/usr/bin/env python
#!/usr/bin/python
##############################################################
#    Interactive main routine, for GeoComp equation.
#    Yasuko Matsubara 
#    Date: 02-10-2015
##############################################################
import model 
import sys
import getopt
import math as M
import tool
from pylab import *
from matplotlib.widgets import Slider, Button
LOGLOGP=0
#---------------#
#     PLOT      #
#---------------#
def _plot(model, dat, plotLog):
    ax = subplot(211); cla();
    X = model.getModel(n)
    if(dat!=[]): plot(dat.T, '-', lw=0.2, markersize=2)
    tool.resetColor()
    plot(X.T, lw=2)
    #axis([0, model.n, 0,1])
    model.printParams('');
    xlabel('Time')
    ylabel('Volume @ time')

def update(val):
    model.p[0] = s1.val
    model.p[1] = s2.val
    model.p[2] = s3.val
    model.r[0] = s4.val
    model.r[1] = s5.val
    model.r[2] = s6.val
    model.K[0] = s7.val
    model.K[1] = s8.val
    model.K[2] = s9.val
    model.A[0][0] = s00.val
    model.A[0][1] = s01.val
    model.A[0][2] = s02.val
    model.A[1][0] = s10.val
    model.A[1][1] = s11.val
    model.A[1][2] = s12.val
    model.A[2][0] = s20.val
    model.A[2][1] = s21.val
    model.A[2][2] = s22.val
    _plot(model, dat, LOGLOGP)
    draw()


def reset(event):
    s1.reset()
    s2.reset()
    s3.reset()
    s4.reset()
    s5.reset()
    s6.reset()
    s7.reset()
    s8.reset()
    s9.reset()
    s00.reset()
    s01.reset()
    s02.reset()
    s10.reset()
    s11.reset()
    s12.reset()
    s20.reset()
    s21.reset()
    s22.reset()

def logscale(event):
    global LOGLOGP
    if(LOGLOGP!=1):
        LOGLOGP+=1
    else:
        LOGLOGP=-1 


#---------------#
#     init      #
#---------------#
# check args
if(len(sys.argv)==2):
    modelfn=sys.argv[1]
else:
    modelfn=''
dat=[]; n=100;
# --- model parameters --- #
d = 3; # default dimension
# if initial model
if(modelfn!=''):
    md0 = model.GeoCompG(d,1, dat)
    md0.readParams(modelfn);
    model = model.GeoCompG(d,1, dat)
    model.readParams(modelfn);
    n=model.n;
# if no initial model
else:
    md0   = model.GeoCompG(d,n, dat)
    model = model.GeoCompG(d,n, dat)
_plot(md0, dat, LOGLOGP);

# GUI: slide bars
axcolor = 'lightgoldenrodyellow'
hvcolor = 'darkgoldenrod'
p1  = axes([0.15, 0.35, 0.25, 0.03], axisbg=axcolor)
p2  = axes([0.15, 0.30, 0.25, 0.03], axisbg=axcolor)
p3  = axes([0.15, 0.25, 0.25, 0.03], axisbg=axcolor)
p4  = axes([0.15, 0.20, 0.25, 0.03], axisbg=axcolor)
p5  = axes([0.15, 0.15, 0.25, 0.03], axisbg=axcolor)
p6  = axes([0.15, 0.10, 0.25, 0.03], axisbg=axcolor)
p7  = axes([0.55, 0.20, 0.25, 0.03], axisbg=axcolor)
p8  = axes([0.55, 0.15, 0.25, 0.03], axisbg=axcolor)
p9  = axes([0.55, 0.10, 0.25, 0.03], axisbg=axcolor)
#
p00  = axes([0.55, 0.35, 0.05, 0.03], axisbg=axcolor)
p01  = axes([0.55, 0.30, 0.05, 0.03], axisbg=axcolor)
p02  = axes([0.55, 0.25, 0.05, 0.03], axisbg=axcolor)
p10  = axes([0.70, 0.35, 0.05, 0.03], axisbg=axcolor)
p11  = axes([0.70, 0.30, 0.05, 0.03], axisbg=axcolor)
p12  = axes([0.70, 0.25, 0.05, 0.03], axisbg=axcolor)
p20  = axes([0.85, 0.35, 0.05, 0.03], axisbg=axcolor)
p21  = axes([0.85, 0.30, 0.05, 0.03], axisbg=axcolor)
p22  = axes([0.85, 0.25, 0.05, 0.03], axisbg=axcolor)
#
rmin=0; rmax=1.0;
s1  =  Slider(p1, 'p[0]',  0,  1, valinit=md0.p[0])
s2  =  Slider(p2, 'p[1]',  0,  1, valinit=md0.p[1])
s3  =  Slider(p3, 'p[2]',  0,  1, valinit=md0.p[2])
s4  =  Slider(p4, 'r[0]',   rmin,  rmax, valinit=md0.r[0])
s5  =  Slider(p5, 'r[1]',   rmin,  rmax, valinit=md0.r[1])
s6  =  Slider(p6, 'r[2]',   rmin,  rmax, valinit=md0.r[2])
s7  =  Slider(p7, 'K[0]',   rmin,  rmax, valinit=md0.K[0])
s8  =  Slider(p8, 'K[1]',   rmin,  rmax, valinit=md0.K[1])
s9  =  Slider(p9, 'K[2]',   rmin,  rmax, valinit=md0.K[2])
#
mi=0.0; ma=1.0
s00  =  Slider(p00, 'c00',  mi , ma, valinit=md0.A[0][0])
s01  =  Slider(p01, 'c01',  mi , ma, valinit=md0.A[0][1])
s02  =  Slider(p02, 'c02',  mi , ma, valinit=md0.A[0][2])
s10  =  Slider(p10, 'c10',  mi , ma, valinit=md0.A[1][0])
s11  =  Slider(p11, 'c11',  mi , ma, valinit=md0.A[1][1])
s12  =  Slider(p12, 'c12',  mi , ma, valinit=md0.A[1][2])
s20  =  Slider(p20, 'c20',  mi , ma, valinit=md0.A[2][0])
s21  =  Slider(p21, 'c21',  mi , ma, valinit=md0.A[2][1])
s22  =  Slider(p22, 'c22',  mi , ma, valinit=md0.A[2][2])
#


# GUI: buttons
Logax     = axes([0.15, 0.03, 0.1, 0.04])
buttonLog = Button(Logax, 'Lin/Lin', color=axcolor, hovercolor=hvcolor)
resetax   = axes([0.25, 0.03, 0.1, 0.04])
button    = Button(resetax, 'Reset', color=axcolor, hovercolor=hvcolor)

# event listeners
s1.on_changed(update)
s2.on_changed(update)
s3.on_changed(update)
s4.on_changed(update)
s5.on_changed(update)
s6.on_changed(update)
s7.on_changed(update)
s8.on_changed(update)
s9.on_changed(update)
s00.on_changed(update)
s01.on_changed(update)
s02.on_changed(update)
s10.on_changed(update)
s11.on_changed(update)
s12.on_changed(update)
s20.on_changed(update)
s21.on_changed(update)
s22.on_changed(update)
button.on_clicked(reset)
buttonLog.on_clicked(logscale)
buttonLog.on_clicked(update)
show()



