#!/bin/python
##############################################################
#    Yasuko Matsubara 
#    Date: 12-11-2014
##############################################################
import sys
import pylab
import numpy as np
import math as M
import tool
import matplotlib.pyplot as plt


class SEASON:
    def __init__(self, d, n, Pp):
        self.d = d; self.n = n; self.Pp=Pp;
        self.maxk=d;
        self.resetSEASON()
    def resetSEASON(self):
        _allocSEASON(self, self.d, self.n, self.Pp)
    # get idx-th seasonal pattern
    def getEidx(self, n, idx):
        return _genEidx(self, n, idx)
    # get full (d) seasonal patterns
    def getE(self, n):
        return _genE(self, n)
    def readParams(self, fn):
        _readParams(self, fn)
    def printParams(self, fn):
        _printParams(self, fn)
    def copySEASON(self):
        return _copy(self)
    def getOptk(self):
        return _getOptk(self)
    def bucketize(self,Snb):
        _bucketizeS(self,Snb)
    def getSnb(self):
        return self.Snb
 
 
#--------------------------------------------#
#
#    PRIVATE FUNCS
#
#--------------------------------------------#
def _copy(season):
    new = SEASON(season.d,season.n,season.Pp)
    new.S = season.S.copy()
    new.W = season.W.copy()
    new.Snb = season.Snb
    return new

def _allocSEASON(season, d, n, Pp):
    # seasonal components of length Pp
    season.S=np.zeros((d,Pp))
    # weight matrix of size (d x d)
    season.W=np.zeros((d,d)) 
    season.Snb=0;

# get # of nonzero rows
def _getOptk(season):
    S = season.S;
    optk = sum(np.sum(abs(S),axis=1)>0)
    #print np.shape(S)
    #print optk
    return optk


def _bucketizeS(season, Snb):
    S=season.S;
    # find min, max values of S
    Smax=max(S.flatten()); Smin=min(S.flatten())
    bucketwd=(Smax-Smin)/Snb;
    #print("bucketwd:%f"%bucketwd)
    S_b=np.floor(S/bucketwd)*bucketwd
    season.S = S_b;
    season.Snb=Snb;

def _genE(season,n):
    d = season.d; Pp = season.Pp;
    S = season.S; W = season.W;
    E = np.zeros((d,n))
    for i in range(0,d):
        for t in range(0,n):
            E[i][t]=0.0;
            for k in range(0,d):
                E[i][t] += W[i][k]*S[k][np.mod(t,Pp)]
    return E
def _genEidx(season,n,idx):
    d = season.d; Pp = season.Pp;
    S = season.S; W = season.W;
    Ei = np.zeros(n)
    for t in range(0,n):
        Ei[t] = 0.0;
        for k in range(0,d):
            Ei[t] += W[idx][k]*S[idx][np.mod(t,Pp)]
    return Ei


def _readParams(season, fn):
    #print("read seasonal model parameters (S) ...")
    season.S=pylab.loadtxt(fn+'_season_S', ndmin=2)
    season.W=pylab.loadtxt(fn+'_season_W', ndmin=2)
    (season.d, season.Pp) = np.shape(season.S)
    #print("S[%d][%d]"%(season.d,season.Pp))
def _printParams(season, fn):
    if(fn==''):
        print(season.S); return;
    np.savetxt(fn+'_season_S', season.S, fmt='%.3f', delimiter="\t")
    np.savetxt(fn+'_season_W', season.W, fmt='%.3f', delimiter="\t")

#---------------#
#     main      #
#---------------#
if __name__ == "__main__":
 
    d=3; n=200; Pp=52
    season=SEASON(d,n, Pp)
    season.S[0]=np.random.rand(Pp)
    season.S[1]=pylab.loadtxt("dat/B")

    season.printParams('')
    E = season.getE(n)
    Ei = season.getEidx(n,0)
    season.printParams("dat/season")
    season.readParams("dat/season")
    season.printParams('')

    season.getOptk()
    print('bucketize')
    Snb=30;
    season.bucketize(Snb)
    season.printParams('')
    print("Snb:%d"%(season.getSnb()))

    plt.figure()
    plt.plot(season.S.T)
    plt.show()


