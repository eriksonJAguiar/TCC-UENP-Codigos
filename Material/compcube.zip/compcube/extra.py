#!/bin/python
##############################################################
#    Yasuko Matsubara 
#    Date: 02-10-2015
##############################################################
import sys
import pylab
import numpy as np
import math as M
import tool
import compress
import copy
import os
class EXTRA:
    def __init__(self, d, n):
        self.d = d; self.n = n; 
        self.cF=compress.cF;
        self.resetEXTRA()
    def resetEXTRA(self):
        # extra E[d][]
        self.E = [[]]*self.d
    def resetEXTRAi(self,i):
        self.E[i]=[];
    def addEXTRA(self, i, t, val): 
        _add(self,i,t,val)

    def readParams(self, fn):
        _readParams(self, fn)
    def printParams(self, fn):
        _printParams(self, fn)

    def copyEXTRA(self):
        return _copy(self)

    def getOptK(self):
        return _getOptK(self)

#--------------------------------------------#
#
#    PRIVATE FUNCS
#
#--------------------------------------------#
def _getOptK(extra):
    optk=0
    for i in range(0,extra.d):
        optk+=len(extra.E[i])
    return optk

def _copy(extra):
    new = EXTRA(extra.d,extra.n)
    new.E = copy.deepcopy(extra.E)
    return new
def _add(extra,i,t,val):
    if(len(extra.E[i])==0):
        extra.E[i]=[[t,val]]
    else:
        extra.E[i].append([t,val])

def _readParams(extra, fn):
    extra.resetEXTRA()
    fn=fn+'_extra'
    #print("read extra model parameters (model_extra) ...")
    if(os.stat(fn).st_size == 0): return; 
    try: Emat=pylab.loadtxt(fn, ndmin=2)
    except: print("no extra"); return;
    if(len(Emat)==0): return; # no data
    (cnt, m) = np.shape(Emat)
    for line in range(0,cnt):
        # format: i t val
        i   = int(Emat[line][0])
        t   = int(Emat[line][1]) 
        val = Emat[line][2] 
        extra.addEXTRA(i,t,val)

def _printParams(extra, fn):
    if(fn==''):
        sys.stdout = sys.__stdout__
    else:
        fn = fn + '_extra'
        f = open(fn, 'w')
        sys.stdout = f
    # for each seq i
    for i in range(0,extra.d):
        # e[0]:i, e[1]:val
        for e in extra.E[i]:
            print("%d %d %f"%(i,e[0],e[1]))
        
    sys.stdout = sys.__stdout__
    if(fn!=''):
        f.close()

#---------------#
#     main      #
#---------------#
if __name__ == "__main__":
 
    d=2; n=500; Pp=52
    extra=EXTRA(d,n)
    extra.printParams('')

    new=extra.copyEXTRA()
    new.addEXTRA(0,1,1)
    print('current')
    extra.printParams('')
    print('copy')
    new.printParams('')
    print(extra.getOptK())
    print(new.getOptK())
