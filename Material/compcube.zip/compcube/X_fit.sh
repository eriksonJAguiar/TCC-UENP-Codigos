# CompCube model-fitting #
#--- please selecte label: products/news_sources
label="products"
#label="news_sources"


# SETTING
#---------------------------#
outdir="./OUT/_tmp/"
datadir="./DATA/dat/"
inputlist="./DATA/datlst/list-"$label
mkdir $outdir
mkdir $outdir$label
#---------------------------#
output=$outdir$label"/out/"
input=$output"list"
mkdir $output
echo $inputlist
cat $inputlist | awk '{printf("'$datadir'%s\n", $0)}' > $input
#---------------------------#


# --- (A) Global analysis ------#
python main_fit.py -s $input -t 'g' -o $output # -d 'on'  # display:on/off
#---------------------------#

# --- (B) Local analysis -------#
if [ 1 = 0 ]; then
#---------------------------#
# LocalFit
python main_fit.py -s $input -t 'l' -o $output -d 'off'
# AutoCompress (compress/sparse)
python main_fit.py -s $input -t 'c' -o $output 
# AutoCompress (seasonal components)
python main_fit.py -s $input -t 's' -o $output 
# reconstruction (optional)
#python main_fit.py -s $input -t 'r' -o $output 
#---------------------------#
# Google world map
outL=$output"Comp/baseL/"
outG=$output"Gm/"
rm -r $outG
mkdir $outG
d=`wc $inputlist | awk '{print $1}'`
echo $d
for ((i=1;i<=$d; i++)) 
do
echo .
sh Gmap/make_maps.sh $outL"LA_"$i $outG"Gm_LA_"$i
done
#---------------------------#
fi


