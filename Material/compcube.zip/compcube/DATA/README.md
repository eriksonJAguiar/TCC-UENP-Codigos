======================================
[CompCube Dataset (small)](http://www.cs.kumamoto-u.ac.jp/~yasuko/)
======================================

Author:    Yasuko Matsubara 

Created:   2016-05-16

------------
Introduction
------------

This is a dataset of GoogleTrend 
(https://www.google.com/trends/)

Please also see `compcube_data.zip` (full version)



