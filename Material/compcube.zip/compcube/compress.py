#!/bin/python
##############################################################
#    Yasuko Matsubara 
#    Date: 02-10-2015
##############################################################
import numpy as np
import math
from scipy.stats import norm
import tool
import model 
import ica
import pylab
import copy
import time

ZERO=1.e-100
INF= 1.e+100
cF=8 #32 # defaulf cF 
DBG=0
MAXBUCKETS=1.0/ZERO #1.0e+8 #ZERO
MAXBUCKETS=100 #1.0e+4
FMT="%.16f"

#----------------------------------#
#
# compression 
#
#----------------------------------#
def make_ltensors(modelG,modelL,outdir):
    tool.comment("Compression base")
    tic = time.clock()
    #------------------------------------------------------------#
    (Lp,Lr,LK,LA, modelL_r) = _make_ltensors(modelG,modelL,outdir);
    #------------------------------------------------------------#
    toc = time.clock(); fittime= toc-tic;
    print("time: %f"%fittime)
    return (Lp,Lr,LK,LA, modelL_r); 
def make_season(modelG, modelL, outdir):
    tool.comment("Compression seasonality")
    tic = time.clock()
    #------------------------------------------------------------#
    (S,C,W,modelL)=_make_season(modelG, modelL, outdir);
    #------------------------------------------------------------#
    toc = time.clock(); fittime= toc-tic;
    print("time: %f"%fittime)
    return (S,C,W,modelL);
def make_Etensor(modelG,modelL,outdir):
    tool.comment("Compression extras")
    tic = time.clock()
    #------------------------------------------------------------#
    (E,modelL)=_make_Etensor(modelG,modelL,outdir);
    #------------------------------------------------------------#
    toc = time.clock(); fittime= toc-tic;
    print("time: %f"%fittime)
    return (E,modelL)
#----------------------------------#
#
# reconstruction 
#
#----------------------------------#
def make_season_rec(modelL,fn):
    (modelL, costM)=_make_season_rec(modelL,fn);
    return (modelL, costM)
def make_ltensors_rec(modelG,fn):
    (modelL_r,costM)=_make_ltensors_rec(modelG,fn);
    return (modelL_r,costM)
def make_Etensor_rec(modelL,fn):
    (modelL, costM)=_make_Etensor_rec(modelL,fn);
    return (modelL, costM)





def coding(Xorg,Xrec):
    Delta = Xrec-Xorg;
    Delta[np.isnan(Delta)]=0
    if(DBG): print(  np.sqrt(np.mean(pow(Delta, 2))) ) # RMSE
    Delta=Delta*MAXBUCKETS # to avoid inf pdf
    std=np.std(Delta)+ZERO; mean=np.mean(Delta);
    pdfs=norm.pdf(Delta, mean, std)
    #---  if laplacian distribution
    #loc=mean; scale=std; x=Delta;
    #pdfs= np.exp(-abs(x-loc)/scale)/(2.*scale) 
    #---  endif laplacian distribution
    pdfs[pdfs>1]=1; # to avoid costC<0, optional
    pdfs[pdfs<=ZERO]=ZERO
    pdfsL=-np.log2(pdfs)
    cost = np.nansum(pdfsL)
    if(DBG): print(cost) 
    return cost

def CostM_base(nP, d, l, cF):
    costM=nP*(tool.log2(d)+tool.log2(3)+tool.log2(l)+cF)+tool.log_s(nP)
    return costM
    #return ( nP*(tool.log2(d)+tool.log2(3)+tool.log2(l)+cF) )
def CostM_comp(nC, d, l, cF):
    costM=nC*(2*tool.log2(d)+tool.log2(l)+cF)+tool.log_s(nC)
    return costM
    #return ( nC*(2*tool.log2(d)+tool.log2(l)+cF) )
def CostM_season(nS, nW, k, d, l, Pp, cF):
    costM = tool.log_s(k)+tool.log_s(nS)+tool.log_s(nW);
    costM += (nS)*(tool.log2(k)+tool.log2(Pp)+cF)
    costM += (nW)*(tool.log2(d)+tool.log2(k)+tool.log2(l)+cF)
    return costM 
def CostM_extra(nD, d,l,n, cF):
    costM = (nD)*(tool.log2(d)+tool.log2(n)+tool.log2(l)+cF)+tool.log_s(nD)
    return costM
    #return ( k*(tool.log2(d)+tool.log2(n)+tool.log2(l)+cF) )


def bucketize(X,nb):
    Xb=X.copy()
    maxV=max(Xb.flatten()); minV=min(Xb.flatten());
    if(maxV==minV): return Xb;
    bucketwd=(maxV-minV)/nb;
    Xb=np.floor(Xb/bucketwd)*bucketwd
    return Xb
def bucketizeLOG(X,nb):
    Xb=X.copy(); ZERist=[X<=ZERO];
    Xb[ZERist]=1;  # replace 0->1
    Xb=2**bucketize(np.log2(Xb),nb)
    Xb[ZERist]=0;  # replace 1->0
    return Xb



 
#----------------------------#
# compress local model, etc. 
#----------------------------#
def alloc_modelL(modelG,l):
    d=modelG.d; n=modelG.n; 
    tool.comment("alloc modelL")
    modelL=[] # modelL[l]
    # (b) load local params
    for j in range(0,l):
        model_p=modelG.copyModel();
        modelL.append(model_p)
    return modelL




def countLOG(Xorg):
    X=Xorg.copy();
    X[X<=ZERO]=1;
    Xl=np.log2(X);
    return count(Xl);
def count(X):
    return len(X[abs(X)>ZERO].flatten());



#------------------------------------#
#
# create sparse tensors 
#    (modelL->modelL_reconstruct))
#
#------------------------------------#
# Lp[d][l], Lr[d][l], LK[d][l], LA[d][d][l]
def _make_ltensors(modelG,modelL,outdir):
    d=modelG.d; n=modelG.n; l=len(modelL);
    print(d,l,n)
    # (a) alloc tensors
    Lp=np.zeros((d,l))
    Lr=np.zeros((d,l))
    LK=np.zeros((d,l))
    LA=np.zeros((d,d,l))
    # (b) compute tensors 
    for i in range(0,d):
        for j in range(0,l):
            Lp[i][j]=(modelL[j].p[i])/(modelG.p[i]+ZERO)
            Lr[i][j]=(modelL[j].r[i])/(modelG.r[i]+ZERO)
            LK[i][j]=(modelL[j].K[i])/(modelG.K[i]+ZERO)
            for ii in range(0,d):
                LA[i][ii][j]=(modelL[j].A[i][ii])/(modelG.A[i][ii]+ZERO)
    # (c) compress tensors
    BP=2; Cprev=INF; 
    modelL_r=alloc_modelL(modelG,l);
    for pp in range(8,16): #2^8=256,...)
        nb=BP**pp #BP, BP^2, BP^3 ...
        # bucketize tensors
        (Lp_b,Lr_b,LK_b,LA_b)=_bucketizeALL(Lp,Lr,LK,LA,nb)
        # count non-zero values 
        (nLp,nLr,nLK,nLA)=_countALL(Lp_b,Lr_b,LK_b,LA_b)
        # reconstruct local params
        modelL_r=_reconst(modelG,modelL_r,Lp_b,Lr_b,LK_b,LA_b)
        l_s=int(l*0.1+1) # check 10% data 
        costC=0; 
        for j in range(0,l_s):
            costC+=modelL_r[j].cost();
        costC/=l_s; # average costC
        # costM(base)-avg
        costMb=CostM_base((nLp+nLr+nLK)/l, d, 1, np.log2(nb))
        # costM(comp)-avg
        costMc=CostM_comp((nLA)/l ,d, 1, np.log2(nb))
        # total cost
        costT=costC+costMb+costMc;
        print("nb:%d, %d"%(nb, np.log2(nb))) 
        print("costC, costM, costT=%.2f, %.2f, %.2f"%(costC, costMb+costMc, costT))
        if(Cprev<=costT): break;
        optnb=nb; Cprev=costT; 
    print("best buckets %d"%optnb)
    (Lp,Lr,LK,LA)=_bucketizeALL(Lp,Lr,LK,LA,optnb) 
    modelL_r=_reconst(modelG,modelL_r,Lp_b,Lr_b,LK_b,LA_b)
    # (d) save tensors
    np.savetxt(outdir+'nb', [optnb],fmt="%d")
    np.savetxt(outdir+'Lp', Lp.T, fmt=FMT, delimiter="\t")
    np.savetxt(outdir+'Lr', Lr.T, fmt=FMT, delimiter="\t")
    np.savetxt(outdir+'LK', LK.T, fmt=FMT, delimiter="\t")
    for i in range(0,d):
        np.savetxt(outdir+'LA_%d'%(i+1), LA[i].T, fmt=FMT, delimiter="\t")
    return (Lp,Lr,LK,LA, modelL_r)

def _make_ltensors_rec(modelG,fn):
    tool.comment('load data (ltensors)')
    nb=int(pylab.loadtxt(fn+'nb',ndmin=1)[0]);
    Lp=pylab.loadtxt(fn+'Lp', ndmin=2).T
    Lr=pylab.loadtxt(fn+'Lr', ndmin=2).T
    LK=pylab.loadtxt(fn+'LK', ndmin=2).T
    (d,l)=np.shape(Lp);
    modelL_r=alloc_modelL(modelG,l);
    LA=np.zeros((d,d,l))
    d=modelG.d; n=modelG.n; 
    for i in range(0,d):
        LA[i]=pylab.loadtxt(fn+'LA_%d'%(i+1), ndmin=2).T
    costM=_costM_ltensors(modelG,Lp,Lr,LK,LA,nb);
    print('costM(base):%.0f'%(costM))
    tool.comment('reconst modelL (ltensors)')
    modelL_r=_reconst(modelG,modelL_r,Lp,Lr,LK,LA)
    return (modelL_r,costM)
#-------------------------------------#
# for make_ltensors()
#-------------------------------------#
def _costM_ltensors(modelG,Lp,Lr,LK,LA,nb):
    d=modelG.d; n=modelG.n; (d,l)=np.shape(Lp);
    cF=tool.log2(nb);
    # global params
    nA=count(modelG.A);
    costM_G=d*3*cF + CostM_comp((nA), d, 1, cF)
    # local params
    (nLp,nLr,nLK,nLA)=_countALL(Lp,Lr,LK,LA)
    costM_L= CostM_base((nLp+nLr+nLK),d,l,cF)+CostM_comp((nLA),d,l,cF)
    return costM_G+costM_L
 
def _bucketizeALL(Lp,Lr,LK,LA, nb):
    Lp_b=bucketizeLOG(Lp,nb);
    Lr_b=bucketizeLOG(Lr,nb);
    LK_b=bucketizeLOG(LK,nb);
    LA_b=bucketizeLOG(LA,nb);
    return (Lp_b,Lr_b,LK_b,LA_b);
def _countALL(Lp,Lr,LK,LA):
    nLp=countLOG(Lp);
    nLr=countLOG(Lr);
    nLK=countLOG(LK);
    nLA=countLOG(LA);
    return (nLp,nLr,nLK,nLA)
def _reconst(modelG,modelL,Lp,Lr,LK,LA):
    # reconstruct params
    d=modelG.d; n=modelG.n; l=len(modelL);
    for j in range(0,l):
        for i in range(0,d):
            modelL[j].p[i]=modelG.p[i]*Lp[i][j];
            modelL[j].r[i]=modelG.r[i]*Lr[i][j];
            modelL[j].K[i]=modelG.K[i]*LK[i][j];
            for ii in range(0,d):
                modelL[j].A[i][ii]= modelG.A[i][ii]*LA[i][ii][j];
    return modelL;
#-------------------------------------#

#------------------------------------#
#
# create sparse extra
#    (modelL->modelL_reconstruct))
#
#------------------------------------#
# E[nE][4] - 0:d,1:l,2:n,3:val
def _make_Etensor(modelG,modelL,outdir):
    d=modelG.d; n=modelG.n; l=len(modelL);
    print(d,l,n)
    E=[];
    # (a) create original Extra tensor
    for j in range(0,l):
        for i in range(0,d):
            for [t,val] in modelL[j].extra.E[i]:
                E.append([i,j,t,val]);
    E=np.asarray(E)
    print np.shape(E)
    (nE, a) = np.shape(E);
    # (b) compress tensors
    BP=2; Cprev=INF; 
    modelL_r=alloc_modelL(modelG,l);
    for pp in range(6,8): #2^1=,...)
        nb=BP**pp #BP, BP^2, BP^3 ...
        # bucketize tensors
        Eb=E.copy();
        Eval=Eb[:,3];Eval=bucketize(Eval,nb);Eb[:,3]=Eval;
        modelL_r=_reconstE(modelL_r,Eb)        
        l_s=int(l*0.1+1) # check 10% data #
        costC=0; 
        for j in range(0,l_s):
            costC+=modelL_r[j].cost();
        costC/=l_s; # average costC
        # model cost-avg (ignore)
        costM=0; #CostM_extra(nE/l, d,1,n, np.log2(nb))
        # total cost
        costT=costC+costM;
        print("nb:%d, %d"%(nb, np.log2(nb))) 
        print("costC, costM, costT=%.2f, %.2f, %.2f"%(costC, costM, costT))
        if(Cprev<=costT): break;
        optnb=nb; Cprev=costT; 
    print("best buckets %d"%optnb)
    Eval=Eb[:,3];Eval=bucketize(Eval,optnb);Eb[:,3]=Eval;
    E=Eb;
    # (c) save params
    np.savetxt(outdir+'nb', [optnb],fmt="%d")
    np.savetxt(outdir+'E', E,fmt="%d %d %d %.8f")
    return (E,modelL)

def _make_Etensor_rec(modelL,fn):
    d=modelL[0].d; n=modelL[0].n; l=len(modelL);
    tool.comment('load data (extra)')
    nb=int(pylab.loadtxt(fn+'nb',ndmin=1)[0]);
    E=pylab.loadtxt(fn+'E', ndmin=2)
    (nE, a)=np.shape(E); print("Extra: #E=%d"%(nE))
    costM=_costM_Etensor(E,d,l,n,nb)
    print('costM(base):%.0f'%(costM))
    tool.comment('reconstruct (extra)')
    modelL=_reconstE(modelL,E)
    return (modelL, costM)
#-------------------------------------#
# for make_Etensor()
#-------------------------------------#
def _reconstE(modelL,E):
    # reconstruct params
    l=len(modelL);
    (nE,a)=np.shape(E);
    for j in range(0,l):
        modelL[j].extra.resetEXTRA();
    for ii in range(0,nE):
        (i,j,t,val) = E[ii];
        modelL[int(j)].extra.addEXTRA(int(i),int(t),val);
    return modelL;
def _costM_Etensor(E,d,l,n,nb):
    #d=modelG.d; n=modelG.n; (d,l)=np.shape(Lp);
    cF=tool.log2(nb);
    (nE,a)=np.shape(E);
    costM=CostM_extra(nE, d,l,n, cF);
    return costM
 

#------------------------------------#
#
# create seasononal components 
#    (modelL -> S-> C*W ))
#    C: ICA comps
#    W: weight/mixing tensor
#
#------------------------------------#
# S[d][l][Pp], C[k][Pp], W[k][d][l]
def _make_season(modelG, modelL, outdir):
    d=modelG.d; n=modelG.n; l=len(modelL);
    S =np.zeros((d,l,modelG.season.Pp)) #S[d][l][Pp]
    Sf=np.zeros((d*l,modelG.season.Pp)) #Sf[d*l][Pp], flatten
    # (a) create Season tensors
    for i in range(0,d):
        for j in range(0,l):
            Sf[i*l+j] = modelL[j].season.S[i]*modelL[j].season.W[i][i]; 
            S[i][j]   = modelL[j].season.S[i]*modelL[j].season.W[i][i];
    # (b) find Components
    mink=1; maxk=2*d; X=Sf.T;
    (optk, S_, A_, M_, optnb) = ica.ica_optk(X,mink,maxk)
    (S_, A_, M_) = ica.positive(S_,A_,M_)
    C=S_.T; # components
    W=np.zeros((optk,d,l)) 
    for k in range(0,optk):
        for i in range(0,d):
            for j in range(0,l):
                W[k][i][j]=A_[i*l+j][k]
    # (c) plot results
    ica.plotResults(Sf.T, C.T, W, outdir);
    # (d) reconstruct;
    modelL=_reconstS(modelL,C,W);
    # (e) save params
    np.savetxt(outdir+'nb', [optnb],fmt="%d")
    np.savetxt(outdir+'Sf', Sf.T, fmt=FMT, delimiter="\t")
    np.savetxt(outdir+'C',  C.T,  fmt=FMT, delimiter="\t")
    for k in range(0,optk):
        np.savetxt(outdir+'W_%d'%(k+1), W[k].T, fmt=FMT, delimiter="\t")
    _makeTopS(S, outdir)
    return (S,C,W,modelL)

def _make_season_rec(modelL,fn):
    d=modelL[0].d; n=modelL[0].n; l=len(modelL);
    tool.comment('load data (season)')
    nb=int(pylab.loadtxt(fn+'nb',ndmin=1)[0]);
    C=pylab.loadtxt(fn+'C', ndmin=2).T
    (k,Pp)=np.shape(C);
    W=np.zeros((k,d,l))
    for i in range(0,k):
        W[i]=pylab.loadtxt(fn+'W_%d'%(i+1), ndmin=2).T
    costM=_costM_S(C,W,nb)
    print('costM(season):%.0f'%(costM))
    tool.comment('reconstruct (season)')
    modelL=_reconstS(modelL,C,W)
    return (modelL, costM)
#-------------------------------------#
# for make_season()
#-------------------------------------#
def _reconstS(modelL, C,W):
    (optk,Pp)=np.shape(C);
    (optk,d,l)=np.shape(W);
    for i in range(0,d):
        modelL[i].season.resetSEASON();
        for j in range(0,l):
            rec=0.0;
            for k in range(0,optk):
                rec+=W[k][i][j]*C[k]
            modelL[j].season.S[i]=rec;
            modelL[j].season.W[i][i]=1; 
    return modelL
def _makeTopS(S, outdir):
    (d,l,Pp)=np.shape(S)
    # --- tp & sp --- #
    S_tp=np.zeros((d,l)); S_sp=np.zeros((d,l))
    for i in range(0,d):
        for j in range(0,l):
            Sij=S[i][j];
            S_tp[i][j]=np.argmax(Sij); 
            S_sp[i][j]=Sij[np.argmax(Sij)]; 
    np.savetxt(outdir+'S_tp', S_tp, fmt='%.3f', delimiter="\t")
    np.savetxt(outdir+'S_sp', S_sp, fmt='%.3f', delimiter="\t")
    # --- tp & sp --- #
def _costM_S(C,W,nb):
    cF=tool.log2(nb);
    (Pp,k)=np.shape(C)
    (k,d,l)=np.shape(W)
    print("season:k:%d"%(k))
    nC=count(C)
    nW=count(W)
    costM = CostM_season(nC, nW, k, d, l, Pp, cF)
    return costM

#---------------#
#     main      #
#---------------#
if __name__ == "__main__":
    print("test")
