#!/bin/python
##############################################################
#    Yasuko Matsubara 
#    Date: 02-10-2015
##############################################################
#import matplotlib as mpl
#mpl.use('Agg')
import sys
import math as M
from scipy.stats import poisson
import matplotlib.pyplot as plt
import pylab 
import numpy as np
import tool
import season 
import extra
import compress 
INF=10000000000
PP=52
#ZERO=1.e-4 
ZERO=1.e-100
SPARSE_R=0.5 # data sparseness



#####################
# model-Full
#####################
def _model_Full(model, n):
    d = model.d
    # model-base (i.e., P[d][n])
    X = _model_Base(model, n)
    # model-full (i.e., V[d][n])
    Y = _model_FullEX(model, n, X)
    return Y

#####################
# Given: 
#    n: duration 
#    d: dimension
#    p[d]: initial values
#    r[d]: growth rate
#    K[d]: carrying capacity
#    A[d][d]: interaction matrix 
# -------------------
# Output: X[d][n]
#####################
def _model_Base(model, n):
    d=model.d; #n=model.n;
    p = model.p 
    r=model.r 
    K=model.K
    A=model.A
    X  = np.zeros((d,n)) 
    #--- init value ---#
    for i in range(0,d):
        X[i][0]=p[i]
    #--- start (t=0,...n-1) ---#
    for t in range(0,n-1):
        for i in range(0,d):
            cum = 0.0;
            for j in range(0,d):
                cum += A[i][j]*X[j][t]
            sums=1.0 - cum/K[i];
            X[i][t+1] = X[i][t] + X[i][t]*r[i] * sums
            if(X[i][t+1]<0): X[i][t+1]=0;
    #--- return variables ---#
    return X


def _model_FullEX(model, n, X):
    d = model.d
    # model-full
    Y = np.zeros((d, n))
    # seasonality E
    E = model.season.getE(n)
    Y=X*(1.0+E)
    Y[Y<0]=0; 
    # extra/deltas
    for i in range(0,d):
        for [t,val] in model.extra.E[i]:
            Y[i,t]=val
    return Y


#----------------------------------#
#
#     class GeoCompG 
#
#----------------------------------#
class GeoCompG:
    # d: dimension 
    # n: duration
    # p[d]:   initial values
    # r[d]:    growth rate
    # A[d][d]: interaction matrix 
    # K[d]: carrying capacity
    # p_V=[]; r_V=[]; A_V=[]; K_V=[]; S_V=[]; E_V=[];
    # model.season = season.SEASON(d,n,Pp=PP)
    # model.extra  = extra.EXTRA(d,n)

    def __init__(self, d, n, data):
        self.data=data
        self.allocModel(d, n)
        _initParams(self)
    def initParams(self):
        _initParams(self)
    def initVary(self, wantVary):
        _initVary(self, wantVary)
    def allocModel(self, d, n):
        _allocModel(self, d, n)
    def copyModel(self):
        return _copyModel(self)

    def getModel(self, n=-1):
        # default: generate X of length n
        if(n==-1): n = self.n 
        return _model_Full(self, n) 

    def getModelEX(self, X):
         # default: generate X of length n
        return _model_FullEX(self, self.n, X) 

    def getModelEXidx(self, X, idx):
         # default: generate X of length n
        return _model_FullEXidx(self, self.n, X, idx) 

    def getModelBase(self, n=-1):
        # default: generate X of length n
        if(n==-1): n = self.n 
        return _model_Base(self, n) 

    def dist(self, scale):
        return _dist(self, scale)
    def dist_each(self, scale):
        return _dist_each(self, scale)
    def cost(self):
        model=self; zero2nan=True;
        (rmse, costC)= _distEC(self, zero2nan);
        return costC

    def distEC(self): # rmse & costC
        (rmse, costC)= _distEC(self, True);
        return (rmse, costC);

    def saveModel(self, outdir, wantBlock=False):
        if(outdir!=''):
            outdir=(outdir+"fit")
        tool.comment("save data: [%s]"%outdir)
        print("rmse:%f, cost:%f"%(self.dist("lin"), self.cost()))
        # fitting results (png)
        _plotFit(  self, outdir, wantBlock, 2)
        _plotModel(self, outdir, wantBlock, 1)
        # parameter set
        self.printParams(outdir)
        if(outdir!=''):
            self.season.printParams(outdir)
            self.extra.printParams(outdir)
        tool.comment("")
 
    def printParams(self, fn):
        _printParams(self, fn)
    def readParams(self, fn):
        #tool.comment('read model:'+fn)
        fn=fn+"fit"
        _readParams(self, fn+"_base")
        self.season.readParams(fn)
        self.extra.readParams(fn)
        #self.printParams('')
        try: self.data=pylab.loadtxt(fn+'_seq_org.txt').T
        except: self.data=[];

#----------------------------------#
#
#     private functions 
#
#----------------------------------#
def _allocModel(model, d, n):
    model.d  = d # of dimension
    model.n  = n # of duration
    model.p = np.zeros(d)    # p: initial values
    model.r  = np.zeros(d)    # r: growth rate
    model.A  = np.identity(d) # A: interaction matrix
    model.K  = np.ones(d)     # K: carrying capacity
    # vary (1: true, 0: false)
    model.initVary(1)
    # seasonal activity
    model.season = season.SEASON(d,n,Pp=PP)
    # extra 
    model.extra = extra.EXTRA(d,n)

def _initParams(model):
    for i in range(0,model.d):
        model.K[i] = 1.0
        model.p[i] = 0 # 0.5
        model.r[i] = 0 #0.01 
        for j in range(0,model.d):
            model.A[i][j]= 0 #0.1 
        model.A[i][i]=1.0
def _initVary(model, wantVary):
    # vary (1: true, 0: false)
    d = model.d
    model.p_V   = wantVary*np.ones(d)
    model.r_V   = wantVary*np.ones(d)
    model.A_V   = wantVary*np.ones((d,d))
    model.K_V   = wantVary*np.ones(d)
    model.S_V   = wantVary*np.ones(d)
    model.E_V   = wantVary*np.ones(d)

def _copyModel(model):
    new = GeoCompG(model.d, model.n, model.data)
    new.p  = model.p.copy()
    new.r  = model.r.copy()
    new.A  = model.A.copy()
    new.K  = model.K.copy()
    new.p_V  = model.p_V.copy()
    new.r_V  = model.r_V.copy()
    new.A_V  = model.A_V.copy()
    new.K_V  = model.K_V.copy()
    new.S_V  = model.S_V.copy()
    new.E_V  = model.E_V.copy()
    new.season = model.season.copySEASON()
    new.extra = model.extra.copyEXTRA()
    return new

def _readParams(model, fn):
    #print("read base model parameters (p, r, a) ...")
    f = open(fn, 'r')#
    d = int(f.readline().rstrip().split(' ')[1])
    n = int(f.readline().rstrip().split(' ')[1])
    if(model.d < d):
        tool.warning('d(current) < d(model)')
        model.d = d
    if(model.n < n):
        tool.warning('n(current) < n(model)')
        model.n = n
    model.allocModel(model.d,model.n)
    # p
    f.readline()
    p = f.readline().rstrip().split(' ')
    for i in range(0,d):
        model.p[i] = float(p[i])
    # r
    f.readline()
    r = f.readline().rstrip().split(' ')
    for i in range(0,d):
        model.r[i] = float(r[i])
    # K
    f.readline()
    K = f.readline().rstrip().split(' ')
    for i in range(0,d):
        model.K[i] = float(K[i])
    # a
    f.readline()
    for i in range(0,d):
        a = f.readline().rstrip().split(' ')
        for j in range(0,d):
            model.A[i][j] = float(a[j])
    f.close()
    #model.printParams('')

def _printParams(model, fn):
    if(fn!=''):
        f = open(fn+'_base', 'w')
        sys.stdout = f
    print "d= %d" %model.d
    print "n= %d" %model.n
    print "p:"
    for i in range(0,model.d):
        print u"%.4e" % model.p[i],
    print ""
    print "r:"
    for i in range(0,model.d):
        print u"%.8f" % model.r[i],
    print ""
    print "K:"
    for i in range(0,model.d):
        print u"%.8f" % model.K[i],
    print ""
    print "A:"
    for i in range(0,model.d):
        for j in range(0,model.d):
            print u"%.8f" % model.A[i][j],        
        print ""
    if(fn!=''):
        sys.stdout = sys.__stdout__
        f.close()


def _rmse(A,B):
    diff=A.flatten()-B.flatten();
    diff[np.isnan(diff)]=0;
    rmse=np.sqrt(np.mean(pow(diff,2)));
    return rmse;

def _distEC(model,zero2nan):
    # if data is null, return 0
    if(model.data==[]):  return (0,0)
    data=model.data.copy();
    X=model.getModel();
    (d,n)=np.shape(data)
    X = X[0:d,0:n]
    # ignore zero values
    if(zero2nan): data[data<=0]=np.nan;
    # rmserror
    rmse=_rmse(data,X);
    # coding cost
    costC=compress.coding(data,X)
    return (rmse, costC); 


def _dist(model, scale):
    data= model.data
    if(data==[]): return 0
    (d,n)=np.shape(data)
    X = model.getModel();
    X = X[0:d,0:n]
    return _rmse(data,X);

def _dist_each(model, scale):
    data= model.data
    if(data==[]): return 0
    (d,n)=np.shape(data)
    X = model.getModel();
    X = X[0:d,0:n]
    D = np.zeros(d);
    for i in range(0,d):
        D[i] = _rmse(data[i],X[i])
    return D


def _plotFit(model, fn, wantBlock, figid):
    tool.figure(figid)
    X = model.getModel();
    # (a) plot sequences
    pylab.title("rse=%f, costC=%d, extra=%d"%(model.dist('lin'), model.cost(),model.extra.getOptK()))
    pylab.xlabel("Time")
    pylab.ylabel("x_i @ time ")
    # (a-1) plot original data
    tool.resetColor()
    if(model.data!=[]):
        pylab.plot(model.data.T, '-', lw=0.2)
    # (a-2) plot model fitting result
    tool.resetColor()
    pylab.plot(X.T, lw=1)
    plt.xlim(0,model.n)
    pylab.draw()
    pylab.show(block=wantBlock)
    # (b) save data
    if(fn!=''):
        pylab.savefig(fn+'_fig_fit.png')
        pylab.savetxt(fn+'_seq_fit.txt', model.getModel().T, delimiter=" ", fmt="%.16f")
        pylab.savetxt(fn+'_seq_fitb.txt', model.getModelBase().T, delimiter=" ", fmt="%.16f")
        if(model.data!=[]):
            pylab.savetxt(fn+'_seq_org.txt', model.data.T, delimiter=" ", fmt="%.16f")

def _plotModel(model, fn, wantBlock, figid):
    tool.figure(figid)
    d = model.d; n=model.n;
    vmA=max(abs(model.A.flatten()))
    vmr=max(abs(model.r.flatten()))
    vmXi=max(abs(model.p.flatten()))
    vmK=max(abs(model.K.flatten()))
    # (a-1) p
    plt.subplot(261)
    plt.imshow(model.p.reshape(d,1), interpolation='nearest',vmin=-vmXi,vmax=vmXi)
    #plt.gray()
    pylab.title("p")
    plt.xticks([]); plt.yticks(np.arange(0,d), range(1,d+1))
    # (a-2) original r
    plt.subplot(262)
    plt.imshow(model.r.reshape(d,1), interpolation='nearest', vmin=-vmr,vmax=vmr)
    pylab.title("r")
    plt.xticks([]); plt.yticks(np.arange(0,d), range(1,d+1))
    # (a-3) original K
    plt.subplot(263)
    plt.imshow(model.K.reshape(d,1), interpolation='nearest', vmin=-vmK,vmax=vmK)
    pylab.title("K")
    plt.xticks([]); plt.yticks(np.arange(0,d), range(1,d+1))
    # (b-1) original C
    plt.subplot(222)
    plt.imshow(model.A, interpolation='nearest',vmin=-vmA,vmax=vmA)
    plt.xticks(np.arange(0,d), range(1,d+1))
    plt.yticks(np.arange(0,d), range(1,d+1))
    #plt.colorbar()
    pylab.title("C")
    pylab.subplot(224)
    pylab.plot(model.season.S.T)
    plt.xlim(0,model.season.Pp)
    pylab.title("S (k=%d)"%(model.season.getOptk()))
    # (c) E matrix
    pylab.subplot(223)
    # (c) W matrix
    vmW=max(abs(model.season.W.flatten()))
    plt.imshow(model.season.W, interpolation='nearest',vmin=-vmW,vmax=vmW) 
    plt.yticks(np.arange(0,d), range(1,d+1))
    plt.colorbar()
    pylab.draw()
    # save data if you want
    if(fn!=''):
        pylab.savefig(fn+'_fig_A.png')


#---------------#
#     main      #
#---------------#
if __name__ == "__main__":
    # basic parameters
    n  = 500;
    d  = 2 #3;
    dat=[]
    model = GeoCompG(d, n, dat);
    model.p[0]=0.1; model.r[0]=0.01;
    model.p[1]=0.2; model.r[1]=0.01;
    model.season.S[0]=np.random.rand(PP)
    model.season.S[1]=np.random.rand(PP)*0.1
    model.printParams('');


    model.extra.addEXTRA(1,100,0.5)
    model2=model.copyModel()
    #model.readParams('../output/example/out/')
    #model.readParams('../output/single/s_games4/out/')
    #_plotFit(model, '', 'True', 1);
    _plotFit(model2, '', 'True', 1);


    modelL=model.copyModel() 
    _plotFit(modelL, '', 'True', 1);


