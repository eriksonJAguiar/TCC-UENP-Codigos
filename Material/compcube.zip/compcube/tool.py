#!/bin/python
##############################################################
#    Yasuko Matsubara 
#    Date: August, 2014
##############################################################
import sys
import pylab
import matplotlib.pyplot as plt
import numpy as np
import os
#ZERO = 0.00000000001
#INF  = 1000000000000
ZERO=1.e-10
INF= 1.e+10


####################
# math, etc.
####################
def log_s(x):
    if(x==0): return 0
    return 2.0*np.log2(x)+1.0;
def log2(x):
    if(x==0): return 0
    return np.log2(x)
#######################
# tools for time series  
#######################
#-----------------------------#
# input: X[d][n]    d-dim seq
#        wd:        window-size
# output: Y[d][n]   smooth seq
#-----------------------------#
def smoothMA(X, wd):
    wd = int(wd)
    if(wd==1):
        return X
    # X[d][n]
    d=len(X)
    n=len(X[0])
    Y = np.zeros((d,n))
    for i in range(0,d):
        Y[i] = np.convolve(X[i], np.ones(wd)/wd, mode='same')
    return Y
#-----------------------------#
# input: X[d][n]    d-dim seq
#        wd:        window-size
# output: Y[d][int(n/wd)]   smooth seq
#-----------------------------#
def smoother(X, wd):
    wd = int(wd)
    if(wd==1):
        return X
    # X[d][n]
    d=len(X)
    n=len(X[0])
    n2=int(n/wd)
    Y = np.zeros((d,n2))
    for i in range(0,d):
        for j in range(0,n2):
            sum=0
            for w in range(0,wd):
               sum+=X[i][j*wd+w] 
            Y[i][j]=sum
    return Y
        
#-----------------------------#
# input:  X[n]  
# output: Y[n]   normalized seq
#-----------------------------#
def normalize01(X):
    n = np.shape(X)
    Y = np.zeros((n))
    xmax=max(X); xmin=min(X);
    Y=(X-xmin)/(xmax-xmin+ZERO)
    return Y

def normalizeVar(X):
    n = np.shape(X)
    Y = np.zeros((n))
    mean=0; std=np.std(X)
    Y = X/(std+ZERO);
    return Y

def normalize0Var(X):
    n = np.shape(X)
    Y = np.zeros((n))
    X=X-min(X); # set zero
    mean=0; std=np.std(X)
    Y = X/(std+ZERO);
    return Y


def normalizeZ(X):
    n = np.shape(X)
    Y = np.zeros((n))
    mean=np.mean(X); std=np.std(X)
    Y = (X-mean)/(std+ZERO);
    return Y


def zero2nan(X):
    X[X==0]=np.nan
    return X

def nan2zero(X):
    X[np.isnan(X)]=0;
    return X



####################
# display
####################
def error(msg):
    print("====================")
    print(" error              ")
    print("--------------------")
    print("%s"%msg)
    print("====================")
    #raise
    sys.exit(0);
def warning(msg):
    print("*** wmsg *** : %s"%msg)
def dotting(dot='.'):
    sys.stdout.write(dot)
    sys.stdout.flush()
def comment(msg):
    print("--------------------")
    print(" %s"%msg)
    print("--------------------")
def notfin():
    print("--------------------")
    print(" NOT FIN ")
    print("--------------------")
def figure(fid):
    plt.figure(fid) 
    plt.ion(); pylab.cla();
    plt.subplot(111)
    #plt.draw(); 
def resetColor():
    try:
        pylab.gca().set_color_cycle(None); return;
    except:
	warning("color")
    try: 
        pylab.gca().set_prop_cycle(None); return; 
    except:
        warning("prop")
 

#def eprint(msg):
#    print >> sys.stderr, (msg)

#######################
# tools for tensor 
#######################
def loadTensor(seqfn):
    print("%s"%seqfn)
    X = [];
    f = open(seqfn, "r")
    comment("load data...")
    for fn in f.read().splitlines():
        print(fn) # check file name
        tmp=pylab.loadtxt(fn, ndmin=2).T
        if(X==[]): X=[tmp];
        else: X=np.vstack([X, [tmp]])
    f.close()
    print("+++++++")
    if(len(X)==0): error("no data")
    # X: 3-order tensor
    (d,l,n)=np.shape(X)
    print("(d,l,n)=(%d,%d,%d)"%(d,l,n))
    return X;

def normTensor(X):
    (d,l,n)=np.shape(X)
    for i in range(0,d):
        for j in range(0,l):
            X[i][j] = normalize01(X[i][j]);
            #X[i][j] = normalize0Var(X[i][j]);
            #X[i][j] = normalizeVar(X[i][j]);
            #X[i][j] = zero2nan(X[i][j]);
            X[i][j] = nan2zero(X[i][j]);
    return X;

def calcGlobal(X):
    (d,l,n)=np.shape(X)
    Xg=np.zeros((d,n))
    for i in range(0,d):
        Xl=X[i]
        Xlm=np.ma.masked_array(Xl,np.isnan(Xl))
        Xg[i]=np.mean(Xlm, axis=0) # mean
        #if(np.sum(Xg[i])==0): error('zero value - Xg[%d]'%(i))
        #Xg[i]=normalize0Var(Xg[i])
        Xg[i]=normalize01(Xg[i])
    return Xg;

####################
# IO, etc.
####################
def mkdir(dir):
    try: os.mkdir(dir)
    except: 
        warning(dir)
        comment('dir exists')
