#!/bin/python
##############################################################
#    Yasuko Matsubara 
#    Date: 11-10-2014
##############################################################
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import pylab
import sys
#import os
import argparse
import tool
import model 
import time
import fit   
import compress
YES=1; NO=0;
WDSIZE=1
INF=1.e+8
#------------------------#
#
#     main function   
#     e.g., python main_fit.py [-h] [-s SEQFN] [-t MTYPE] [-o OUTDIR] [-n N]
#
#------------------------#
if __name__ == "__main__":
    #--- arguments ---#
    parser = argparse.ArgumentParser()
    parser.add_argument("-s",  "--seqfn", type=str, help="input seqs filename")
    parser.add_argument("-t",  "--mtype", type=str, help="fitting [g/l/c]")
    parser.add_argument("-o",  "--outdir",type=str, help="output dir (optional)")
    parser.add_argument("-n",  "--n",     type=int, help="set duration n (optional)")
    parser.add_argument("-d",  "--disp",  type=str, help="want GUI plots? - on (optional)")
    args = parser.parse_args()
    if(len(sys.argv)<5):
        parser.print_help()
    #--- check sequencefn, mtype ---#
    if(args.seqfn!=None and args.mtype!=None):
        seqfn = args.seqfn
        mtype = args.mtype
    else: parser.print_help()
    #--- check output dir ---#
    if(args.outdir!=None): outdir = args.outdir
    else: tool.error('outdir==NULL');
    #--- check n (duration) ---#
    if(args.n>1): my_n=args.n
    else: my_n=INF
    #--- check wantDisplay ---#
    if(args.disp=='on'): wantDisp=YES; 
    else: wantDisp=NO;
    #--- print args ---#
    tool.comment('args')
    print "-------------------------"
    print "mtype: [%s]"%mtype
    print "seqfn: [%s]"%seqfn
    print "outdir:[%s]"%outdir
    print "-------------------------"
    if(mtype!='g' and mtype!='l' and mtype!='c' and mtype!='s' and mtype!='r'):
        tool.error("usage: mtype=[g/l/c/s/r]")

    #--- load data ---#
    X=tool.loadTensor(seqfn);
    #--- normalize data ---#
    X=tool.normTensor(X);
    (d,l,n)=np.shape(X)
    Xg=tool.calcGlobal(X);

    #--- set data length (my_n) ---#
    if(my_n<n):
        X=X[:,:,0:my_n];
        Xg=Xg[:,0:my_n];
        (d,l,n)=np.shape(X)
    # if forecast (nrec>n)
    if(mtype=='r' and my_n<INF): nrec=my_n;
    else: nrec=n;
    #--- print data size ---#
    print "-------------------------"
    print 'd:' , d
    print 'l:' , l
    print 'n:' , n
    print "-------------------------"

    #=======================#
    # global fitting 
    #=======================#
    modelG = model.GeoCompG(d,n,Xg);
    if(mtype=='g'):
        tool.mkdir(outdir+"fitG")
        modelG = fit.Gfit(modelG, outdir+"fitG/", wantDisp);
        sys.exit(0);

    #----------------------------#
    # selected locals 
    List=range(0,l);
    SELECTED=NO;#YES # default:NO
    if(SELECTED):
        #List=[45]#
        #List=[221,39, 80,73,219,104,190, 173, 212, 179, 218, 13,150, 136,10,30, 45,98,183,106,112, 153,188,63]
        #List=[221,39,72,168,153,104,30,45,106] #products
        #List=[221,168,161,136,30,88,163,44]  #beer
        #List=[221,39,219,104,73,98,106,13]   #software
        #List=[221,39,72,168,161,136,88,163,44,219,73,98,13,153,104,30,45,106] #full-selected
        List=map(int,List-np.ones(np.shape(List)))
    else:
        List=range(0,l);
    #----------------------------#

    #=======================#
    # local fitting 
    #=======================#
    if(mtype=='l'):
        tool.mkdir(outdir+"fitL")
        # (a) load global params
        modelG.readParams(outdir+"fitG/")
        #List=range(0,l);
        # (b) fit local params
        modelL=fit.Lfit(X, modelG, outdir+"fitL/", wantDisp, List)
        sys.exit(0);

    #=======================#
    # compress, find season comps
    #=======================# 
    if(mtype=='c' or mtype=='s'):
        tool.mkdir(outdir+"Comp")
        tool.comment("(a-1) load global params");
        modelG.readParams(outdir+"fitG/")
        tool.comment("(a-2) load local params");
        modelL=compress.alloc_modelL(modelG, l);
        for j in List: #range(0,l):
            modelL[j].readParams(outdir+'fitL/'+'%d_'%(j+1))
        if(mtype=='c'):
            tool.comment("create local tensors");
            tool.mkdir(outdir+"Comp/baseG")
            modelG.saveModel(outdir+"Comp/baseG/")
            tool.mkdir(outdir+"Comp/baseL")
            (Lp,Lr,LK,LA,modelLc)=compress.make_ltensors(modelG,modelL,outdir+"Comp/baseL/");
            tool.mkdir(outdir+"Comp/extra")
            (E,modelLc)=compress.make_Etensor(modelG,modelL,outdir+"Comp/extra/")
        if(mtype=='s'):
            tool.comment("create seasonal comps")
            tool.mkdir(outdir+"Comp/season")
            (S,C,W,modelLc)=compress.make_season(modelG, modelL,outdir+"Comp/season/")
        sys.exit(0);


    #=======================#
    # reconstruct 
    #=======================# 
    if(mtype=='r'):
        tool.comment("reconstruct localfit")
        tool.comment("load global params");
        modelG.readParams(outdir+"Comp/baseG/")
        tool.mkdir(outdir+"Comp/rec_fitL")
        #--- (I) reconstruct params --- #
        # (a) reconstruct local tensors
        (modelL,costM_ltensor)= compress.make_ltensors_rec(modelG,outdir+"Comp/baseL/");
        # (b) reconstruct local seasonality
        (modelL,costM_season) = compress.make_season_rec(modelL,outdir+"Comp/season/");
        # (c) reconstruct extra
        (modelL,costM_extra)  = compress.make_Etensor_rec(modelL,outdir+"Comp/extra/")
        #--- (II) cost, dist, etc. ---#
        # (a) use original data
        X[X<=0]=np.nan;
        for j in List: modelL[j].data=X[:,j,:]
        # (b) costM
        costM=costM_ltensor+costM_season+costM_extra;
        costC=0; RMSE=0;
        for j in List: 
            (rmse_b, costC_b)=modelL[j].distEC();
            costC+=costC_b; RMSE+=rmse_b;
            tool.dotting('.')
        print("")
        costT=costM+costC; RMSE/=l;
        print("costT costM costC RMSE: %.0f %.0f %.0f %.8f"%(costT,costM,costC,RMSE))
        np.savetxt(outdir+'Comp/costTMCerr.txt',[[costT,costM,costC,RMSE]],fmt="%.0f %.0f %.0f %.8f")
        if(True): # if you want to plot rec-fitL, then "True"
            tool.mkdir(outdir+"Comp/rec_fitL")
            for j in List: 
                modelL[j].n=nrec
                modelL[j].saveModel(outdir+'Comp/rec_fitL/'+'%d_'%(j+1))
        sys.exit(0);




