======================================
[CompCube Dataset](http://www.cs.kumamoto-u.ac.jp/~yasuko/)
======================================

Author:    Yasuko Matsubara 

Created:   2016-05-16

------------
Introduction
------------

This is a dataset of GoogleTrend 
(https://www.google.com/trends/)

--------
Datasets
--------

- README.md       
- countries.list (country-code list)
- keywords.list  (133 keywords)
- ./dat/...             (133 files) 
- ./datlst/...          (8 examples, d=10 keywords for each list)
- ./misc/countries.csv  (code & name)  
- ./misc/Amazon.US.csv  (original csv file)


----------------
Data description
----------------

e.g., 
./dat/Amazon   
	size: (n x m)= 567 x 237 

n= 567 (duration) --- from January, 2004 to November, 2014. Weekly volume.
m= 237 (location) --- countries/territories.  

Also please see: 
	- `./misc/Amazon.US.csv` (original csv file from GoogleTrend)
	- `./misc/countries.csv` (country code & name)


------------
References
------------

Please see, 
Yasuko Matsubara, Yasushi Sakurai, Christos Faloutsos, 
"Non-Linear Mining of Competing Local Activities", WWW 2016.


------------
Updates
------------

Version: `5-16-2016`
    - released



