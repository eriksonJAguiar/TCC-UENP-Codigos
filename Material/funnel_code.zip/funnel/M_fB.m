function [ fB ] = M_fB(  )
%M_FB Summary of this function goes here
%   Detailed explanation goes here
fB=32;

end

